import { Component } from '@angular/core';

@Component({
  selector: 'app-curosel',
  templateUrl: './curosel.component.html',
  styleUrl: './curosel.component.css'
})
export class CuroselComponent {

}
